using UnityEngine;
using UnityEngine.SceneManagement;
//using UnityEngine.UI;

public class spaceStart : MonoBehaviour
{
    public int scene;
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(scene);
        }
    }

    
}
