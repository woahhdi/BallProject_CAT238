using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CollectableManager : MonoBehaviour
{
    public int appleCount;                                                                              //allows for this to be referenced elsewhere
    public Text pointsText;                                                                             //allows for the text to be implemented in the inspector 
    public static CollectableManager Instance;                              //creating an instance of the CollectableManager
    public GameObject[] persistentObjects;

    //[Header("Persistent Objects")]                                        //creates an array (not working, giving error)
    
    
    
    
    private void Awake()
    {
        if (Instance != null && Instance != this)                            //if there is an instance of the game manager, run CleanUpAndDestroy
        {
            CleanUpAndDestroy();
            return;
        }
        else                                                                //else, set the current object to be the instance
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            MarkPersistentObjects();
        }
    }

    void Start()
    {
        pointsText.text = "Pts: " + appleCount.ToString();
    }
    
    private void MarkPersistentObjects()                                    //Goes through the objects in array of game objects and marks objects as DontDestroyOnLoad
    {
        foreach (GameObject obj in persistentObjects)
        {
            if (obj != null)
            {
                DontDestroyOnLoad(obj);
            }
        }
    }

    private void CleanUpAndDestroy()                                        //Destroys duplicate objects in array
    {
        foreach (GameObject obj in persistentObjects)
        {
            Destroy(obj);
        }

        Destroy(gameObject);
    }
    
    
    void Update()
    {
        pointsText.text = "Pts: " + appleCount.ToString();                                              //updates points with Pts: text as well
    
        if(appleCount <= 0 && (appleCount != 0))                                                        //if the apple count is less than 0 and NOT 0, then run the start screen.
        {
            SceneManager.LoadScene(3);
            //pointsText.text = 0.ToString();
        }

        //if(scene = 4 )
    }
} 



                                                                                                        //video reference: https://www.youtube.com/watch?v=5GWRPwuWtsQ