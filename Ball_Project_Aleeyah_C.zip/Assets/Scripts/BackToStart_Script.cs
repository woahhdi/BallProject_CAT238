using UnityEngine;
using UnityEngine.SceneManagement;


public class BackToStart_Script : MonoBehaviour
{
        void OnCollisionEnter2D(Collision2D other)
    {

        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Collision detected.");
            ChangeScene();
        }
    }

        void ChangeScene()
    {
        SceneManager.LoadScene(0);
    }
}
