using UnityEngine;
using UnityEngine.UI;

public class RandomTextColor : MonoBehaviour
{
    public SpriteRenderer background;
    public GameObject backgroundSprite;

    void Start()
    {
        background = backgroundSprite.GetComponent<SpriteRenderer>();
        background.color = new Color(Random.value,
                                    Random.value,
                                    Random.value);
        //Debug.Log("Changed color.");
    }

    

    
}
