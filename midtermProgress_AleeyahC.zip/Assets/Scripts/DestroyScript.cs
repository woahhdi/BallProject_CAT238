using UnityEngine;

public class DestroyScript : MonoBehaviour
{

    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag == "Player")                                //if the player collides with the collectable object
        {
            Debug.Log("Player collect.");
            DestroyCollectable();                                           //it will be destroyed
        }
    }

    
    void DestroyCollectable()                                               //Destroy object custom function
    {
        Destroy(gameObject);
    }
}
