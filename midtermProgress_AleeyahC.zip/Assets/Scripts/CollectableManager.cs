using UnityEngine;
using UnityEngine.UI;

public class CollectableManager : MonoBehaviour
{
    public int appleCount;                                                                              //allows for this to be referenced elsewhere
    public Text pointsText;                                                                             //allows for the text to be implemented in the inspector 
   
    
    void Update()
    {
        pointsText.text = "Pts: " + appleCount.ToString();                                              //updates points with Pts: text as well
    }
}



                                                                                                        //video reference: https://www.youtube.com/watch?v=5GWRPwuWtsQ