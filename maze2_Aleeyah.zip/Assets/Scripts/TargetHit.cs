using UnityEngine;




// ****** this script doesn't do anything yet because it 
// 1) isn't attached to anything 
// AND
// 2) isn't done

public class TargetHit : MonoBehaviour
{
    public Rigidbody myRB;
    public Rigidbody PlayerRB;
    private bool targetHit;
    public Material hitMaterial;
    public Material unHitMaterial;
    public int targetHitCounter;
    
   // public GameManager gameManager;
    private float myX;
    private float myY;
    private float myZ;
    public Vector3 myTransfom;



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
       // myRB = GetComponent<Rigidbody>();
        //targetHit = false;
       // targetHitCounter = 0;
    
    }

    // Update is called once per frame
    void Update()
    {
        
        
    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "Player")
        {
       //    TargetHasBeenHit();
        }
    }

    void TargetHasBeenHit()
    {
     //   targetHit = true;
     //   targetHitCounter = targetHitCounter++;
     //   Debug.Log("target hit counter is " + targetHitCounter);

    }
}
