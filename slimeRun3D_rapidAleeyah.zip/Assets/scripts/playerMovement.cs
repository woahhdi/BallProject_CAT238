using UnityEngine;

public class playerMovement : MonoBehaviour
{
    
    public Rigidbody rb;
    public float speed;
    public float jumpForce;


    //Assigning keys
    public KeyCode rightMoveKey1;
    public KeyCode rightMoveKey2;
    public KeyCode leftMoveKey1;
    public KeyCode leftMoveKey2;
    public KeyCode forwardsMoveKey1;
    public KeyCode forwardsMoveKey2;
    public KeyCode backwardsMoveKey1;
    public KeyCode backwardsMoveKey2;
    public KeyCode jumpKey;

    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody>();              //Assigning the rb variable
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(rightMoveKey1) || Input.GetKey(rightMoveKey2))         //Moving right two ways
        {
            MoveRight();
        }

        if (Input.GetKey(leftMoveKey1) || Input.GetKey(leftMoveKey2))           //Moving left two ways
        {
            MoveLeft();
        }

        if (Input.GetKey(forwardsMoveKey1) || Input.GetKey(forwardsMoveKey2))
        {
            MoveForward();
        }

        if (Input.GetKey(backwardsMoveKey1) || Input.GetKey(backwardsMoveKey2))
        {
            MoveBackwards();
        }

        if (Input.GetKey(jumpKey))
        {
            Jump();
        }

        else
        {
            rb.AddForce(Vector3.zero);
        }
    }

    void MoveRight()
    {
        rb.AddForce(new Vector3(1, 0, 0) * speed);
    }

    void MoveLeft()
    {
        rb.AddForce(new Vector3(-1, 0, 0) * speed);
    }

    void MoveForward()
    {
        rb.AddForce(Vector3.forward * speed);
    }

    void MoveBackwards()
    {
        rb.AddForce(-Vector3.forward * speed);
    }

    void Jump()
    {
        rb.AddForce(Vector3.up * jumpForce);
    }
}
