using UnityEngine;

public class Green_Ball_Script : MonoBehaviour
{

    public float moveSpeed; //public means it will appear in the inspector.
    public float jumpForce; //private means variable will not appear in the inspector.
    public GameObject greenBall;

    //rb stands for rigidbody
    public Rigidbody2D my_rb;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
        Debug.Log("Oh. Hello there. This is the GreenBallScript's start ;P");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow)) {   //if statements need a { after, not a ;

            Debug.Log("right arrow key pressed");   //strings need ; after

            //Grabbing rigidbody and adding force. Impulse force = common way to apply force to objects. Vector2 = basis of all movement. Vector2 has 2 numbers, x and y.
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);

            
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Debug.Log("left arrow key pressed");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.UpArrow) || (Input.GetKeyDown(KeyCode.Space))) // The symbol || means or.
        {
            Debug.Log("Up arrow pressed");

            Jump();
        }

        void Jump()  //functions should always be capitalized. It should always be a verb.
        {
            Debug.Log("MY FIRST CUSTOM FUNCTION IS RUNNING!!");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);  //Vector2(x,y) is a custom Vector2. 0 = x, y = 1 in this case. Cannot multiply this.
        }
    }
}
