using UnityEngine;

public class PointsScript : MonoBehaviour
{
   public CollectableManager cm;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Apple"))
        {
            Destroy(other.gameObject);                              //destroys collectable after collision
            cm.appleCount++;                                        //adds to points counter
        }

        //if (other.gameObject.CompareTag("Dead"))                  //trying to figure out how to reset points after death. also how to
        //{                                                         //reset apples after death.
        //    cm.appleCount--;
        //    Debug.Log("Lose points.");
        //}
    }
}
