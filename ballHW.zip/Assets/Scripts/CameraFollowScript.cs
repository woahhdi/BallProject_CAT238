using UnityEngine;

public class CameraFollowScript : MonoBehaviour
{

    public Transform followObject;



    // Update is called once per frame
    void FixedUpdate()
    {
        Vector3 currentPosition = transform.position;

        currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);

        currentPosition.z = -10;

        transform.position = currentPosition;
    }
}
