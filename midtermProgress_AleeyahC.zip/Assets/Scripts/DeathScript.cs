using UnityEngine;

public class DeathScript : MonoBehaviour
{
    public GameObject player;
    public Transform respawnPoint;
  
    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.CompareTag("Player"))
        {
            player.transform.position = respawnPoint.position;                  //when the player collides into this game object, the player
        }                                                                       //will return to the set respawn point
    }
}


                                                                                //code reference video: https://www.youtube.com/watch?v=tBj-FWcIwYw 