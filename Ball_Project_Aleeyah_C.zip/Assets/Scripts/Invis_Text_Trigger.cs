using UnityEngine;

public class Invis_Text_Trigger : MonoBehaviour
{
    
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Collision detected.");
            Ouch();
        }
    }

    void Ouch()
    {
        Debug.Log("OUCH!!");
    }

    
}
