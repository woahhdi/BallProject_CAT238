using Unity.VisualScripting;
using UnityEngine;
//using UnityEngine.SceneManagement;

public class PointsScript : MonoBehaviour
{
   CollectableManager cm;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Apple"))
        {
            Debug.Log("Apple destroyed and points added.");
            Destroy(other.gameObject);                              //destroys collectable after collision
            cm.appleCount++;                                        //adds to points counter
        }

        if (other.gameObject.CompareTag("Dead"))                  //trying to figure out how to reset points after death. also how to
        {                                                         //reset apples after death.
            cm.appleCount--;
            Debug.Log("Lose points.");
        }

        //if (appleCount <= 0)
        //{
        //    SceneManager.LoadScene(0);
        //}
    }

    void Awake()
    {
        cm = GameObject.FindGameObjectWithTag("GameManager").GetComponent<CollectableManager>();
    }
}
