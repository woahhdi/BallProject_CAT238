using UnityEngine;

public class Text_Script : MonoBehaviour
{
    public GameObject helloText;

    private bool showText;

     //Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        showText = false;
    }

     //Update is called once per frame
    void Update()
    {
        if (showText == false)
        {
            helloText.SetActive(false);
        }

        if (Input.GetKey(KeyCode.L))
        {
            showText = true;
            helloText.SetActive(true);
        }
    }
}
