using UnityEngine;
using UnityEngine.SceneManagement;


public class Next_Level_Script : MonoBehaviour
{
       void OnCollisionEnter2D(Collision2D other)
    {
     
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Player collision detected.");
            ChangeScene();
        }
    
    }

    
    void ChangeScene()
    {
        SceneManager.LoadScene(1);
    }
}
