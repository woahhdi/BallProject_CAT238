using System;
using UnityEngine;

public class PlayerMovement3D : MonoBehaviour

{

    // *** PHYSICS VARIABLES***
    public Rigidbody rb;
    public float speed;
    public float jumpForce;

    //public LayerMask GroundLayer;
    //public BoxCollider GroundCollider;
    //public bool OnGround;


    //***** KEY ASSIGNMENT *******
    public KeyCode rightMoveKey1;
    public KeyCode rightMoveKey2;
    public KeyCode leftMoveKey1;
    public KeyCode leftMoveKey2;
    public KeyCode forwardMoveKey1;
    public KeyCode forwardMoveKey2;
    public KeyCode backwardsMoveKey1;
    public KeyCode backwardsMoveKey2;
    public KeyCode jumpKey;



    //******* CODE STARTS HERE
    void Start() // START FUNCTION
    { // BEGIN START FUNCTION
        rb = gameObject.GetComponent<Rigidbody>(); //assign the variable 'rb'  
        //OnGround = true;
    } //END START FUNCTION

    // Update is called once per frame
    void Update() // UPDATE FUNCTION
    {//BEGIN UPDATE FUNCTION
        if (Input.GetKey(rightMoveKey1) || Input.GetKey(rightMoveKey2))
        {
            MoveRight();
        }
        if (Input.GetKey(leftMoveKey1) || Input.GetKey(leftMoveKey2))
        {
            MoveLeft();
        }
        if (Input.GetKey(forwardMoveKey1) || Input.GetKey(forwardMoveKey2))
        {
            MoveForward();
        }
        if (Input.GetKey(jumpKey))
        {
            Jump();
        }
        if (Input.GetKey(backwardsMoveKey1) || Input.GetKey(backwardsMoveKey2))
        {
            MoveBackwards();
        } else
        {
            rb.AddForce(Vector3.zero);
        }
    }// END UPDATE FUNCTION


    /*public void OnTriggerEnter(Collider other)
    {
        if(GroundLayer == (1 <<other.gameObject.layer))
        {
            OnGround = true;
        }
    }*/

    //**** MOVEMENT FUNCTIONs ****
    void MoveRight()
    {
        rb.AddForce(Vector3.right * speed);
    }

    void MoveLeft()
    {
        rb.AddForce(Vector3.left * speed);
    }

    void MoveForward()
    {
        rb.AddForce(Vector3.forward * speed);
    }
    
    void MoveBackwards()
    {
        rb.AddForce(-Vector3.forward * speed);
    }

    void Jump()
    {
        rb.AddForce(Vector3.up * jumpForce);
        //OnGround = false;
    }


}//END PLAYER MOVEMENT 3D SCRIPT
