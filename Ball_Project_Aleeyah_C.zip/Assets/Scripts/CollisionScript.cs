using UnityEngine;

public class CollisionScript : MonoBehaviour
{
    public float forceMagnitude = 5f;
    public float changeDirectionIntercal = 2f;

    private Rigidbody rb;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();

    }

    void Awake()
    {

        rb = GetComponent<Rigidbody>();
        ApplyRandomForce();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Collision detected.");
        }

        if ((other.gameObject.tag == "Walls") || (other.gameObject.tag == "Floors"))
        {
            Debug.Log("Walls and floors collision detected.");
        }
    }

    void ApplyRandomForce()
    {
        Vector3 randomDirection = Random.insideUnitSphere.normalized;
        rb.AddForce(randomDirection * forceMagnitude, ForceMode.Impulse);
    }
}
