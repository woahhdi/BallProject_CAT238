using UnityEngine;

public class CameraFollow3D : MonoBehaviour
{
       public Transform target; //this is the transform of the object we want to follow
       public Vector3 offset; //this is a vector 3 of the 3 (x,y,z) offsets from the target



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
   

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = target.position + offset; // set my transform to be equal to the 
                                                        // transform of the target PLUS the 3 offsets 
                                                        // for x,y, and z
    
    }
}
