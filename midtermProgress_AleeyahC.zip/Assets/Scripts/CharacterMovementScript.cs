using UnityEngine;

public class CharacterMovementScript : MonoBehaviour
{
    public float moveSpeed;
    public float jumpForce;
    public GameObject character;
    public LayerMask GroundLayer;                                           //enables input for ground layer
    public BoxCollider2D GroundCollider;                                    //collider for ground
    public bool OnGround;                                                   //boolean for checking if on ground
    public Rigidbody2D my_rb;

    
    void Start()
    {
        Debug.Log("Start of character movement script.");
        OnGround = true;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Debug.Log("Left arrow pressed.");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            Debug.Log("Right arrow pressed.");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if(Input.GetKeyDown(KeyCode.Space) && OnGround)
        {
            Debug.Log("Space pressed.");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            OnGround = false;                                                           //checks if player is on ground
        }
    }

    public void OnTriggerEnter2D(Collider2D other)                                      //
    {
        if(GroundLayer == (1 << other.gameObject.layer))                                //if the player is on the ground layer, then it can jump again
        {
            OnGround = true;
        }
    }
}
