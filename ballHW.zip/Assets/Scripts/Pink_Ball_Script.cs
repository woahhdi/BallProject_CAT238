using UnityEngine;

public class Pink_Ball_Script : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public GameObject pinkBall;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh hey there! This is the start of PinkBallScript!");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            Debug.Log("A key pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            Debug.Log("D key pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if (Input.GetKeyDown(KeyCode.W))
        {
            Debug.Log("W key pressed.");
            
            Jump();
        }

        void Jump()
        {
            Debug.Log("Custom function 2 yay!");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }
    }
}
