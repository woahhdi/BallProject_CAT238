using UnityEngine;

public class Yellow_Star_Script : MonoBehaviour
{

    public float moveSpeed;
    public float jumpForce;
    public GameObject yellowStar;
    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Hello! I'm yellowStarScript!");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
             Debug.Log("Left arrow pressed.");
             my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
         }

        if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            Debug.Log("Right arrow pressed.");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }

        if(Input.GetKeyDown(KeyCode.UpArrow) || (Input.GetKeyDown(KeyCode.Space)))
        {
            Debug.Log("Jumping!");
            my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        }

        
    }
}
