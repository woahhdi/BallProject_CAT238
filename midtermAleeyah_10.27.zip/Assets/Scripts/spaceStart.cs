using UnityEngine;
using UnityEngine.SceneManagement;
//using UnityEngine.UI;

public class spaceStart : MonoBehaviour
{
  //  public Text startText;
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(1);
        }
    }

    
}
