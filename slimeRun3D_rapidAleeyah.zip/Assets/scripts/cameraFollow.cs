using UnityEngine;

public class cameraFollow : MonoBehaviour
{
    public Transform target;                        //Transform of the object we want to follow
    public Vector3 offset;                          //Vector3 of the offsets of the target


    void FixedUpdate()
    {
        transform.position = target.position + offset;
    }
}
