using UnityEngine;

public class InstantiateScript : MonoBehaviour
{
    public GameObject myPrefab;
    public GameObject clone;
    
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Vector2 spawnPosition = new Vector2(0f, 0f);
            clone = Instantiate(myPrefab, spawnPosition, Quaternion.identity);
            Debug.Log("Spawned cube.");
        }
    }
}
