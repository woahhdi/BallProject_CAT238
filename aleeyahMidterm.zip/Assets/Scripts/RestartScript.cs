using UnityEngine;
using UnityEngine.SceneManagement;

public class RestartScript : MonoBehaviour
{
    private KeyCode restartKey;
    public KeyCode nextLevel;
    public int currentScene;
    public int nextScene;

    void Start()
    {
        restartKey = KeyCode.R;
    }

    // Update is called once per frame
    void Update()
    {
       if (Input.GetKey(restartKey))
       {
           SceneManager.LoadScene(currentScene);
       }

       if (Input.GetKey(nextLevel))
       {
           SceneManager.LoadScene(nextScene);
       }
    }
}
